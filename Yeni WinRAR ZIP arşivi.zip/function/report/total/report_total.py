from tkinter import *
from function.program.information import start_information
import sqlite3
from datetime import datetime

class Application(object):

    def __init__(self):

        self.main()

    def main(self):

        self.con = sqlite3.connect("database/database.db")
        self.cursor = self.con.cursor()

        #şınav raporu
        self.cursor.execute("SELECT TOTAL FROM SINAV_DATA")
        self.total_sinav = self.cursor.fetchall()
        self.ssinav = 0
        for self.xxx in self.total_sinav:
            self.ssinav += self.xxx[0]

        self.cursor.execute("SELECT DATE FROM SINAV_DATA")
        self.date_sinav = self.cursor.fetchall()

        #koşu raporu
        self.cursor.execute("SELECT DISTANCE FROM KOSU_DATA")
        self.total_kosu = self.cursor.fetchall()
        self.kkosu = 0

        for self.xxxx in self.total_kosu:
            self.kkosu += self.xxxx[0]

        self.cursor.execute("SELECT DATE FROM KOSU_DATA")
        self.date_kosu = self.cursor.fetchall()

        #yürüyüş raporu
        self.cursor.execute("SELECT DISTANCE FROM YURUYUS_DATA")
        self.total_yuruyus = self.cursor.fetchall()
        self.yyuruyus = 0

        for self.xxxxx in self.total_yuruyus:
            self.yyuruyus += self.xxxxx[0]

        self.cursor.execute("SELECT FOOTSTEP FROM YURUYUS_DATA")
        self.total_yuruyusx = self.cursor.fetchall()
        self.yyyuruyus = 0

        for self.xxxxxx in self.total_yuruyusx:
            self.yyyuruyus += self.xxxxxx[0]

        self.cursor.execute("SELECT DATE FROM YURUYUS_DATA")
        self.date_yuruyus = self.cursor.fetchall()

        #mekik raporu
        self.cursor.execute("SELECT TOTAL FROM MEKIK_DATA")
        self.total_mekik = self.cursor.fetchall()

        if len(self.total_mekik) == 0:

            self.total_mekik = [(0,)]

        self.mekikx = 0

        for self.xxxxxxx in self.total_mekik:
            self.mekikx += self.xxxxxxx[0]

        self.cursor.execute("SELECT DATE FROM MEKIK_DATA")
        self.date_mekik = self.cursor.fetchall()

        if len(self.date_mekik) == 0:

            self.date_mekik = "-"

        self.cursor.execute("SELECT TOTAL FROM BARFIKS_DATA")
        self.total_barfiks = self.cursor.fetchall()
        self.barifksx = 0

        if len(self.total_barfiks) == 0:
            self.total_barfiks = [(0,)]

        for self.xxxxxxxx in self.total_barfiks:
            self.barifksx += self.xxxxxxxx[0]

        self.cursor.execute("SELECT DATE FROM BARFIKS_DATA")
        self.date_barfiks = self.cursor.fetchall()

        if len(self.date_barfiks) == 0:
            self.date_barfiks = "-"

        self.pencere1 = Tk()
        self.pencere1.title(start_information.total_rapor_name_title)
        self.pencere1.geometry("880x180+575+390")
        self.pencere1.resizable(FALSE, FALSE)

        self.cerceve1 = Frame(self.pencere1)
        self.cerceve1.grid(row=0, column=1, padx=50)

        #şınav verileri
        self.etiket = Label(self.pencere1, text=self.date_sinav[0][0]+"-"+self.date_sinav[-1][0])
        self.etiket.grid(row=1, column=2)

        self.etiket = Label(self.pencere1, text=str(self.ssinav)+" ADET")
        self.etiket.grid(row=1, column=3)

        self.etiket = Label(self.pencere1, text="---")
        self.etiket.grid(row=1, column=4)

        self.etiket = Label(self.pencere1, text="---")
        self.etiket.grid(row=1, column=5)

        #koşu verileri
        self.etiket = Label(self.pencere1, text=self.date_kosu[0][0]+"-"+self.date_kosu[-1][0])
        self.etiket.grid(row=2, column=2)

        self.etiket = Label(self.pencere1, text="---")
        self.etiket.grid(row=2, column=3)

        self.etiket = Label(self.pencere1, text=str(self.kkosu)+" KM")
        self.etiket.grid(row=2, column=4)

        self.etiket = Label(self.pencere1, text="---")
        self.etiket.grid(row=2, column=5)

        #yürüyüş verileri
        self.etiket = Label(self.pencere1, text=self.date_yuruyus[0][0]+"-"+self.date_yuruyus[-1][0])
        self.etiket.grid(row=3, column=2)

        self.etiket = Label(self.pencere1, text="---")
        self.etiket.grid(row=3, column=3)

        self.etiket = Label(self.pencere1, text=str(self.yyuruyus)+" KM")
        self.etiket.grid(row=3, column=4)

        self.etiket = Label(self.pencere1, text=str(self.yyyuruyus)+" ADIM")
        self.etiket.grid(row=3, column=5)

        #mekik verileri
        self.etiket = Label(self.pencere1, text=self.date_mekik[0][0]+"-"+self.date_mekik[-1][0])
        self.etiket.grid(row=4, column=2)

        self.etiket = Label(self.pencere1, text=str(self.mekikx)+" ADET")
        self.etiket.grid(row=4, column=3)

        self.etiket = Label(self.pencere1, text="---")
        self.etiket.grid(row=4, column=4)

        self.etiket = Label(self.pencere1, text="---")
        self.etiket.grid(row=4, column=5)

        #barfiks verileri
        self.etiket = Label(self.pencere1, text=str(self.barifksx)+" ADET")
        self.etiket.grid(row=5, column=3)

        self.etiket = Label(self.pencere1, text=self.date_barfiks[0][0]+"-"+self.date_barfiks[-1][0])
        self.etiket.grid(row=5, column=2)

        self.etiket = Label(self.pencere1, text="---")
        self.etiket.grid(row=5, column=4)

        self.etiket = Label(self.pencere1, text="---")
        self.etiket.grid(row=5, column=5)


        # satır

        self.sutun_button_name_list = ["TARİH", "TOPLAM", "MESAFE", "ADIM", "RAPOR TARİHİ"]
        self.satir_button_name_list = ["ŞINAV", "KOŞU", "YÜRÜYÜŞ", "MEKİK", "BARFİKS"]

        self.satir = 0
        self.sutun = 2
        self.select_sutun_name = 0
        self.select_satir_name = 0

        for self.i in self.sutun_button_name_list:

            self.buttonxxx = Button(self.pencere1, width=20)
            self.buttonxxx.grid(row=self.satir, column= self.sutun)
            self.buttonxxx["text"] = self.sutun_button_name_list[self.select_sutun_name]
            self.sutun += 1
            self.select_sutun_name += 1

            if self.sutun > 6:

                self.sutun = 1
                self.satir = 1

                for self.ii in self.satir_button_name_list:

                    self.buttonxxxx = Button(self.pencere1, width=16)
                    self.buttonxxxx.grid(row=self.satir, column=self.sutun)
                    self.buttonxxxx["text"] = self.satir_button_name_list[self.select_satir_name]
                    self.satir += 1
                    self.select_satir_name += 1

        self.satir = 1

        for self.iii in self.satir_button_name_list:

            self.etiket = Label(self.pencere1)
            self.etiket.grid(row=self.satir, column=6)
            self.etiket["text"] = datetime.now()
            self.satir += 1

        self.con.close()