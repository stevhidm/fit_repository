from tkinter import *
from function.program.information import start_information
import sqlite3

class Application(object):

    def __init__(self):

        self.main()

    def main(self):

        self.con = sqlite3.connect("database/database.db")
        self.cursor = self.con.cursor()

        self.cursor.execute("SELECT * FROM SINAV_DATA")
        self.sinav_data = self.cursor.fetchall()
        self.con.commit()

        if len(self.sinav_data) == 0:

            self.sinav_data = [(0,0,0)]

        self.cursor.execute("SELECT * FROM YURUYUS_DATA")
        self.yuruyus_data = self.cursor.fetchall()
        self.con.commit()

        if len(self.yuruyus_data) == 0:

            self.yuruyus_data = [(0,0,0,0)]

        self.cursor.execute("SELECT * FROM KOSU_DATA")
        self.kosu_data = self.cursor.fetchall()
        self.con.commit()

        if len(self.kosu_data) == 0:

            self.kosu_data = [(0,0,0)]

        self.cursor.execute("SELECT * FROM MEKIK_DATA")
        self.mekik_data = self.cursor.fetchall()
        self.con.commit()

        if len(self.mekik_data) == 0:

            self.mekik_data = [(0,0,0)]

        self.cursor.execute("SELECT * FROM BARFIKS_DATA")
        self.barfiks_data = self.cursor.fetchall()
        self.con.commit()

        if len(self.barfiks_data) == 0:

            self.barfiks_data = [(0,0,0)]

        self.cursor.execute("SELECT * FROM KG_DATA")
        self.kg_data = self.cursor.fetchall()
        self.con.commit()

        if len(self.kg_data) == 0:

            self.kg_data = [(0,0,0)]

        self.pencere1 = Tk()
        self.pencere1.title(start_information.last_rapor_name_title)
        self.pencere1.geometry("585x200+685+390")
        self.pencere1.resizable(FALSE, FALSE)

        self.cerceve1 = Frame(self.pencere1)
        self.cerceve1.grid(row=0, column=1, padx=50)

        # satır

        self.button1 = Button(self.pencere1, text="İŞLEM TARİHİ", width=14)
        self.button1.grid(row=0, column=2)

        self.button2 = Button(self.pencere1, text="MESAFE", width=14)
        self.button2.grid(row=0, column=3)

        self.button3 = Button(self.pencere1, text="TOPLAM", width=14)
        self.button3.grid(row=0, column=4)

        self.buttonx = Button(self.pencere1, text="KAYIT TARİHİ", width=20)
        self.buttonx.grid(row=0, column=5)

        # sütun

        self.button4 = Button(self.pencere1, text="ŞINAV", width=10)
        self.button4.grid(row=1, column=1)

        self.button5 = Button(self.pencere1, text="YÜRÜYÜŞ", width=10)
        self.button5.grid(row=2, column=1)

        self.button6 = Button(self.pencere1, text="KOŞU", width=10)
        self.button6.grid(row=3, column=1)

        self.button7 = Button(self.pencere1, text="MEKİK", width=10)
        self.button7.grid(row=4, column=1)

        self.button8 = Button(self.pencere1, text="BARFİKS", width=10)
        self.button8.grid(row=5, column=1)

        self.button9 = Button(self.pencere1, text="KG", width=10)
        self.button9.grid(row=6, column=1)

        # şınav tablosu

        self.etiket1 = Label(self.pencere1)
        self.etiket1.grid(row=1, column=2)
        self.etiket1["text"] = self.sinav_data[-1][0]

        self.etiket2 = Label(self.pencere1)
        self.etiket2.grid(row=1, column=4)
        self.etiket2["text"] = self.sinav_data[-1][1]

        self.etiket2x = Label(self.pencere1)
        self.etiket2x.grid(row=1, column=5)
        self.etiket2x["text"] = self.sinav_data[-1][2]

        # yürüyüş tablosu

        self.etiket3 = Label(self.pencere1)
        self.etiket3.grid(row=2, column=2)
        self.etiket3["text"] = self.yuruyus_data[-1][0]

        self.etiket4 = Label(self.pencere1)
        self.etiket4.grid(row=2, column=3)
        self.etiket4["text"] = self.yuruyus_data[-1][1]

        self.etiket5 = Label(self.pencere1)
        self.etiket5.grid(row=2, column=4)
        self.etiket5["text"] = self.yuruyus_data[-1][2]

        self.etiket5x = Label(self.pencere1)
        self.etiket5x.grid(row=2, column=5)
        self.etiket5x["text"] = self.yuruyus_data[-1][3]

        # koşu tablosu

        self.etiket6 = Label(self.pencere1)
        self.etiket6.grid(row=3, column=2)
        self.etiket6["text"] = self.kosu_data[-1][0]

        self.etiket7 = Label(self.pencere1)
        self.etiket7.grid(row=3, column=3)
        self.etiket7["text"] = self.kosu_data[-1][1]

        self.etiket7x = Label(self.pencere1)
        self.etiket7x.grid(row=3, column=5)
        self.etiket7x["text"] = self.kosu_data[-1][2]

        # mekik tablosu

        self.etiket8 = Label(self.pencere1)
        self.etiket8.grid(row=4, column=2)
        self.etiket8["text"] = self.mekik_data[-1][0]

        self.etiket9 = Label(self.pencere1)
        self.etiket9.grid(row=4, column=4)
        self.etiket9["text"] = self.mekik_data[-1][1]

        self.etiket9x = Label(self.pencere1)
        self.etiket9x.grid(row=4, column=5)
        self.etiket9x["text"] = self.mekik_data[-1][2]

        # barfiks tablosu

        self.etiket10 = Label(self.pencere1)
        self.etiket10.grid(row=5, column=2)
        self.etiket10["text"] = self.barfiks_data[-1][0]

        self.etiket11 = Label(self.pencere1)
        self.etiket11.grid(row=5, column=4)
        self.etiket11["text"] = self.barfiks_data[-1][1]

        self.etiket11x = Label(self.pencere1)
        self.etiket11x.grid(row=5, column=5)
        self.etiket11x["text"] = self.barfiks_data[-1][2]

        # kilogram tablosu

        self.etiket12 = Label(self.pencere1)
        self.etiket12.grid(row=6, column=2)
        self.etiket12["text"] = self.kg_data[-1][0]

        self.etiket13 = Label(self.pencere1)
        self.etiket13.grid(row=6, column=4)
        self.etiket13["text"] = self.kg_data[-1][1]

        self.etiket13x = Label(self.pencere1)
        self.etiket13x.grid(row=6, column=5)
        self.etiket13x["text"] = self.kg_data[-1][2]

        self.con.close()