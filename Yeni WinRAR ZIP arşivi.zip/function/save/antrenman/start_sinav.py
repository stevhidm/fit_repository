from tkinter import *
import sqlite3
from function.important.warning import start_warning
from function.important.successfull import start_successfull
from datetime import datetime

class Application(object):

    def __init__(self):

        self.main()

    def main(self):

        self.pencere2 = Toplevel()

        self.pencere2.title("ŞINAV KAYIT EKRANI")
        self.pencere2.resizable(FALSE, FALSE)

        self.pencere2.geometry("+780+450")

        # birinci satır
        self.cerceve1 = Frame(self.pencere2)
        self.cerceve1.grid(row=0, column=0, padx=5)

        self.etiket1 = Label(self.pencere2, text="TARİH >>")
        self.etiket1.grid(row=0, column=1)

        self.cerceve1 = Frame(self.pencere2)
        self.cerceve1.grid(row=0, column=2, padx=5)

        self.girdi1 = Entry(self.pencere2)
        self.girdi1.grid(row=0, column=3)

        # üçüncü satır
        self.cerceve1 = Frame(self.pencere2)
        self.cerceve1.grid(row=2, column=0, padx=5)

        self.etiket3 = Label(self.pencere2, text="TOPLAM >>")
        self.etiket3.grid(row=2, column=1)

        self.cerceve1 = Frame(self.pencere2)
        self.cerceve1.grid(row=2, column=2, padx=5)

        self.girdi2 = Entry(self.pencere2)
        self.girdi2.grid(row=2, column=3)

        # dördüncü satır
        self.cerceve1 = Frame(self.pencere2)
        self.cerceve1.grid(row=3, column=0)

        self.button4 = Button(self.pencere2, text="KAYDET", command=self.save_data)
        self.button4.grid(row=3, column=1)

        self.button5 = Button(self.pencere2, text="TEMİZLE", command=self.delete)
        self.button5.grid(row=3, column=2)

        self.button6 = Button(self.pencere2, text="VAZGEÇ", command=self.pencere2.destroy)
        self.button6.grid(row=3, column=3)

    def save_data(self):

        self.date = self.girdi1.get()
        self.total = self.girdi2.get()

        if len(self.date) != 0 and len(self.total) != 0:

            try:

                self.total = int(self.total)

                self.save_date = datetime.now()

                self.con = sqlite3.connect("database/database.db")
                self.cursor = self.con.cursor()

                self.cursor.execute("INSERT INTO SINAV_DATA VALUES(?,?,?)", (self.date, self.total, self.save_date))
                self.con.commit()

                self.con.close()

                self.girdi1.delete(0, END)
                self.girdi2.delete(0, END)

                start_successfull.Application()

            except:

                start_warning.Application()

        else:

            start_warning.Application()

    def delete(self):

        self.girdi1.delete(0, END)
        self.girdi2.delete(0, END)