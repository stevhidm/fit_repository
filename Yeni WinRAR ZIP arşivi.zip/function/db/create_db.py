import sqlite3

class Application(object):

    def __init__(self):

        self.create_database()

    def create_database(self):

        self.con = sqlite3.connect("database/database.db")
        self.cursor = self.con.cursor()

        self.cursor.execute("CREATE TABLE IF NOT EXISTS SINAV_DATA (DATE TEXT, TOTAL INT, SAVE_DATE TEXT)")
        self.cursor.execute("CREATE TABLE IF NOT EXISTS MEKIK_DATA (DATE TEXT, TOTAL INT, SAVE_DATE TEXT)")
        self.cursor.execute("CREATE TABLE IF NOT EXISTS KG_DATA (DATE TEXT, TOTAL FLOAT, SAVE_DATE TEXT)")
        self.cursor.execute("CREATE TABLE IF NOT EXISTS BOY_DATA (DATE TEXT, TOTAL FLOAT, SAVE_DATE TEXT)")
        self.cursor.execute("CREATE TABLE IF NOT EXISTS YURUYUS_DATA (DATE TEXT, DISTANCE FLOAT, FOOTSTEP INT, SAVE_DATE TEXT)")
        self.cursor.execute("CREATE TABLE IF NOT EXISTS KOSU_DATA (DATE TEXT, DISTANCE FLOAT, SAVE_DATE TEXT)")
        self.cursor.execute("CREATE TABLE IF NOT EXISTS BARFIKS_DATA (DATE TEXT, TOTAL INT, SAVE_DATE TEXT)")

        self.con.commit()

        self.con.close()
