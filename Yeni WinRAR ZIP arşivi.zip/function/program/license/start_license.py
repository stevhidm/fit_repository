from tkinter import *

ceo = "TVHD SOFT #"
web = "tvhdsoft.com"

class Application(object):

    def __init__(self):

        self.main()

    def main(self):

        pass