from tkinter import *
from function.program.information import start_information

class Application(object):

    def __init__(self):

        self.main()

    def main(self):

        self.pencere = Tk()
        self.pencere.title(start_information.yardim_title)
        self.pencere.geometry("+800+400")

        self.pencere.resizable(FALSE, FALSE)

        self.etiket = Label(self.pencere, text="DESTEK İÇİN İLETİŞİME GEÇİNİZ")
        self.etiket.pack()
        self.etiket = Label(self.pencere, text=start_information.e_posta_name)
        self.etiket.pack()