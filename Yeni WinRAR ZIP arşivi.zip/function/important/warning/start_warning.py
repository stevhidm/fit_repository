from tkinter import *

class Application(object):

    def __init__(self):

        self.warning_win = Toplevel()
        self.warning_win.title("UYARI EKRANI")

        self.warning_win.geometry("+670+460")
        self.warning_win.resizable(FALSE, FALSE)

        self.warning_tex = Label(self.warning_win, text="HATALI BİLGİ GİRİŞİ YAPTINIZ! LÜTFEN TEKRAR DENEYİNİZ.",
                                 fg="yellow", bg="black", font="Helvatica, 14 bold")
        self.warning_tex.pack()

        self.warning_but = Button(self.warning_win, text="TAMAM", command=self.warning_win.destroy)
        self.warning_but.pack()