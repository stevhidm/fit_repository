from tkinter import *

class Application(object):

    def __init__(self):

        self.main()

    def main(self):

        self.good_win = Toplevel()
        self.good_win.title("BAŞARI EKRANI")

        self.good_win.geometry("+760+460")
        self.good_win.resizable(FALSE, FALSE)

        self.good_tex = Label(self.good_win, text="KAYIT İŞLEMİ BAŞARILI BİR ŞEKİLDE GERÇEKLEŞTİ.")
        self.good_tex.pack()

        self.good_but = Button(self.good_win, text="TAMAM", command=self.good_win.destroy)
        self.good_but.pack()