from tkinter import *
import sqlite3

class Application(object):

    def __init__(self):

        self.main()

    def main(self):

        self.pencere1 = Tk()

        self.pencere1.title("SİL")

        self.pencere1.geometry("+760+460")

        self.pencere1.resizable(FALSE, FALSE)

        self.dugme1 = Button(self.pencere1, text="TÜM VERİLERİ SİL", width=24, command=self.start_delete)
        self.dugme1.pack()

    def start_delete(self):

        self.pencere1.destroy()

        self.con = sqlite3.connect("database/database.db")
        self.cursor = self.con.cursor()

        self.cursor.execute("DELETE FROM SINAV_DATA")
        self.cursor.execute("DELETE FROM MEKIK_DATA")
        self.cursor.execute("DELETE FROM KG_DATA")
        self.cursor.execute("DELETE FROM YURUYUS_DATA")
        self.cursor.execute("DELETE FROM KOSU_DATA")
        self.cursor.execute("DELETE FROM BARFIKS_DATA")

        self.con.close()

        self.pencere2 = Tk()
        self.dugme2 = Button(self.pencere2, text="TAMAMLANDI", command=self.pencere2.destroy)
        self.dugme2.pack()