from tkinter import *
from PIL import ImageTk, Image
from random import choice

class Application(object):

    def __init__(self):

        self.main()

    def main(self):

        self.wp_list = ["../img/rsz_bg_1.png", "../img/rsz_bg_2.png", "../img/rsz_bg_3.png", "../img/rsz_bg_4.png",
                        "../img/rsz_bg_5.png", "../img/rsz_bg_6.png"]
        self.select_wp = choice(self.wp_list)
        self.root = Tk()
        self.canvas = Canvas(self.root, width=960, height=540)
        self.image = ImageTk.PhotoImage(Image.open(self.select_wp))

        self.canvas.create_image(0,0, anchor = NW, image = self.image)
        self.canvas.pack()

app = Application()
mainloop()

"""

TKINTER BG IMAGE YAPIMI

"""