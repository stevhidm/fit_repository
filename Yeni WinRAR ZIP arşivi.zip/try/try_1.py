import tkinter as tk


def on_closing(toplevel, button):
    button["command"] = lambda: command(button)
    toplevel.destroy()


def command(button):
    button["command"] = lambda: None
    toplevel = tk.Toplevel()
    toplevel.protocol(
        name="WM_DELETE_WINDOW",
        func=lambda: on_closing(toplevel, button)
    )


root = tk.Tk()

button = tk.Button(master=root, text="Button")
button["command"] = lambda: command(button)
button.pack()

root.mainloop()